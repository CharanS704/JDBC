package in.application.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import in.application.dto.Student;
import in.application.service.IStudentService;
import in.application.servicefactory.StudentServiceFactory;

public class TestApp {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		while (true) {
			System.out.println();
			System.out.println("------------Student Management MENU------------");
			System.out.println(" 1 --> create a new record");
			System.out.println(" 2 --> read a record");
			System.out.println(" 3 --> update a record");
			System.out.println(" 4 --> delete a record");
			System.out.println(" 5 --> to exit");
			System.out.println("Please enter your option: ");
			String option = br.readLine();
			switch (option) {
			case "1":
				insertOperation();
				break;
			case "2":
				selectOperation();
				break;
			case "3":
				updateOperation();
				break;
			case "4":
				deleteOperation();
				break;
			case "5":
				System.out.println("-----------Thank you for using the application-----------");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid values entered, Please enter a valid options...");
				break;

			}

		}

		// insertOperation();
		// selectOperation();
		// updateOperation();
		// deleteOperation();
	}

	public static void insertOperation() {

		IStudentService studentService = StudentServiceFactory.getStudentService();

		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter the new student name: ");
		String sname = scanner.next();

		System.out.println("Please Enter the new student age: ");
		int sage = scanner.nextInt();

		System.out.println("Please enter the new student address: ");
		String saddress = scanner.next();

		System.out.println();
		System.out.println("---------------------Executing insert Operation---------------------");

		String msg = studentService.addStudent(sname, sage, saddress);
		if (msg.equalsIgnoreCase("success")) {
			System.out.println("record inserted successfully");
		} else {
			System.out.println("record insertion failed..");
		}

	}

	public static void selectOperation() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter the student id: ");
		int sid = scanner.nextInt();

		IStudentService studentService = StudentServiceFactory.getStudentService();
		Student std = studentService.searchStudent(sid);
		if (std != null) {
			System.out.println();
			System.out.println("---------------------Executing Select Operation---------------------");
			System.out.println(std);
			System.out.println("SID\tSNAME\tSAGE\tSADDR");
			System.out.println(std.getSid() + "\t" + std.getSname() + "\t" + std.getSage() + "\t" + std.getSaddress());
		} else {
			System.out.println("Record not found for given sid: " + sid);
		}

	}

	public static void updateOperation() throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please enter the student id to be updated: ");
		String sid = br.readLine();

		IStudentService studentService = StudentServiceFactory.getStudentService();
		Student student = studentService.searchStudent(Integer.parseInt(sid));

		if (student != null) {
			Student newStudent = new Student();

			System.out.println("Student id  is: " + sid);
			newStudent.setSid(student.getSid());

			System.out.println("Student old name is '" + student.getSname() + "' Please enter new name: ");
			String newName = br.readLine();
			if (newName.equals("") || newName == "") {
				newStudent.setSname(student.getSname());
			} else {
				newStudent.setSname(newName);
			}

			System.out.println("Student old age is '" + student.getSage() + "' Please enter new age: ");
			String newAge = br.readLine();
			if (newAge.equals("") || newAge == "") {
				newStudent.setSage(student.getSage());
			} else {
				newStudent.setSage(Integer.parseInt(newAge));
			}

			System.out.println("Student old address is '" + student.getSaddress() + "' Please enter new address: ");
			String newAddr = br.readLine();
			if (newAddr.equals("") || newAddr == "") {
				newStudent.setSaddress(student.getSaddress());
			} else {
				newStudent.setSaddress(newAddr);
			}

			String status = studentService.updateStudent(newStudent);
			if (status.equalsIgnoreCase("success")) {
				System.out.println("Record updated successfully!!!");
			} else {
				System.out.println("Record updation failed..");

			}


		} else {

			System.out.println("Student record does not exist for given id " + sid + " for updation..");
		}

	}

	public static void deleteOperation() {
		IStudentService studentService = StudentServiceFactory.getStudentService();

		Scanner scanner = new Scanner(System.in);

		System.out.println("Please enter the student id to be deleted: ");
		int sid = scanner.nextInt();

		System.out.println();
		System.out.println("---------------------Executing delete Operation---------------------");

		String msg = studentService.deleteStudent(sid);
		if (msg.equalsIgnoreCase("success")) {
			System.out.println("record deleted successfully");
		} else {
			System.out.println("record deletion failed..");
		}

	}

}
