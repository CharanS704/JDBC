package in.application.persistence;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.application.dto.Student;
import in.application.util.JdbcUtil;

public class StudentDaoImpl implements IStudentDao {
	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet = null;

	@Override
	public String addStudent(String sname, Integer sage, String saddress) {

		String sqlInsertQuery = "insert into Student (`name`,`age`,`address`) values(?,?,?)";

		try {
			connection = JdbcUtil.getJDBCConnection();
			if (connection != null) {
				pstmt = connection.prepareStatement(sqlInsertQuery);
			}

			if (pstmt != null) {
				pstmt.setString(1, sname);
				pstmt.setInt(2, sage);
				pstmt.setString(3, saddress);

				int rowAffected = pstmt.executeUpdate();
				if (rowAffected == 1) {
					return "success";
				}
			}

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		return "failure";
	}

	@Override
	public Student searchStudent(Integer sid) {
		String sqlSearchQuery = "select * from Student where id = ?";
		Student student = null;

		try {
			connection = JdbcUtil.getJDBCConnection();
			if (connection != null)
				pstmt = connection.prepareStatement(sqlSearchQuery);

			if (pstmt != null)
				pstmt.setInt(1, sid);

			resultSet = pstmt.executeQuery();

			if (resultSet != null) {
				if (resultSet.next()) {
					student = new Student();

					// copying resultSet date into Student object
					student.setSid(resultSet.getInt(1));
					student.setSname(resultSet.getString(2));
					student.setSage(resultSet.getInt(3));
					student.setSaddress(resultSet.getString(4));

					return student;
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return student;

	}

	@Override
	public String updateStudent(Student student) {

		String sqlUpdateQuery = "update student set name=?,age=?,address=? where id=?";

		try {
			connection = JdbcUtil.getJDBCConnection();
			if (connection != null) {
				pstmt = connection.prepareStatement(sqlUpdateQuery);
			}

			if (pstmt != null) {
				pstmt.setString(1, student.getSname());
				pstmt.setInt(2, student.getSage());
				pstmt.setString(3, student.getSaddress());
				pstmt.setInt(4, student.getSid());

				int rowAffected = pstmt.executeUpdate();
				if (rowAffected == 1) {
					return "success";
				}
			}

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		return "failure";
	}

	@Override
	public String deleteStudent(Integer sid) {

		String sqlDeleteQuery = "delete from Student where id=?";

		try {
			connection = JdbcUtil.getJDBCConnection();
			if (connection != null) {
				pstmt = connection.prepareStatement(sqlDeleteQuery);
			}

			if (pstmt != null) {
				pstmt.setInt(1, sid);

				int rowAffected = pstmt.executeUpdate();
				if (rowAffected == 1) {
					return "success";
				}
			}

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		return "failure";

	}

}
