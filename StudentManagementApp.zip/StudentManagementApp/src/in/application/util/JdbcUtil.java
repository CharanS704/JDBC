package in.application.util;

import java.io.*;
import java.sql.*;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class JdbcUtil {

	private JdbcUtil() {// To prevent user from creating object for JDBCUtil class

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException ce) {
			ce.printStackTrace();
		}
	}

	public static Connection getJDBCConnection() throws SQLException, IOException {

		// Getting inputs from Properties file
		/*
		 * FileInputStream fis = new
		 * FileInputStream("src\\in\\application\\properties\\application.properties");
		 * Properties properties = new Properties(); properties.load(fis);
		 */

//		String url=properties.getProperty("url");
//		String username=properties.getProperty("username");
//		String password=properties.getProperty("password");
//		System.out.println("Fetching the URL, Username and Password from Propperties file..");

		HikariConfig config = new HikariConfig("src\\in\\application\\properties\\application.properties");
		//Creating dataSource object
		HikariDataSource dataSource = new HikariDataSource(config);
		// Connection connection=DriverManager.getConnection(url,username,password);
		// System.out.println("Implementing class is:
		// "+connection.getClass().getName());
		return dataSource.getConnection();
	}

//	public static void cleanUp(Connection con, Statement stmt, ResultSet rslt) throws SQLException {
//		if(con!=null) {
//			con.close();
//		}
//		
//		if(stmt!=null) {
//			stmt.close();
//		}
//		
//		if(rslt!=null) {
//			rslt.close();
//		}
//	}

}
