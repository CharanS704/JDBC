package in.application.daofactory;
import in.application.persistence.IStudentDao;
import in.application.persistence.StudentDaoImpl;

public class StudentDaoFactory {
	
	private StudentDaoFactory() {
		
	}
	
	private static IStudentDao studentDao = null;
	public static IStudentDao getStudentDao() {
		if(studentDao == null) {
			studentDao = new StudentDaoImpl();
		}
		return studentDao;
	}

}
